"use client"

import { useState, useRef } from "react"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { Trash2 } from "lucide-react"

interface ThoughtReleaserProps {
  onRelease: (thought: string) => void
}

const AFFIRMATIONS = [
  "Released. You are lighter now.",
  "Let go. Peace begins here.",
  "Gone. You are free to move forward.",
  "Released into the wind. Breathe easy.",
  "It no longer holds you. You are at peace.",
  "Surrendered. Your spirit is unburdened.",
  "Cast away. You carry only light now.",
  "Released. The weight has been lifted.",
]

export function ThoughtReleaser({ onRelease }: ThoughtReleaserProps) {
  const [thought, setThought] = useState("")
  const [phase, setPhase] = useState<"input" | "releasing" | "affirmed">(
    "input"
  )
  const [affirmation, setAffirmation] = useState("")
  const containerRef = useRef<HTMLDivElement>(null)

  const handleRelease = () => {
    if (!thought.trim()) return

    const randomAffirmation =
      AFFIRMATIONS[Math.floor(Math.random() * AFFIRMATIONS.length)]
    setAffirmation(randomAffirmation)
    setPhase("releasing")

    // After animation, show affirmation
    setTimeout(() => {
      onRelease(thought.trim())
      setPhase("affirmed")
    }, 1200)

    // Reset after showing affirmation
    setTimeout(() => {
      setThought("")
      setPhase("input")
    }, 4000)
  }

  return (
    <div ref={containerRef} className="flex flex-col items-center gap-6">
      {phase === "input" && (
        <div className="flex w-full flex-col gap-4 animate-fade-in-up">
          <Textarea
            placeholder="Write down the thought, worry, or burden you want to release..."
            value={thought}
            onChange={(e) => setThought(e.target.value)}
            className="min-h-[140px] rounded-xl border-border bg-card text-foreground placeholder:text-muted-foreground/60 focus:border-primary"
            aria-label="Enter a thought to release"
          />
          <Button
            onClick={handleRelease}
            disabled={!thought.trim()}
            className="mx-auto gap-2 rounded-full px-8"
            size="lg"
          >
            <Trash2 className="h-4 w-4" />
            Release This Thought
          </Button>
        </div>
      )}

      {phase === "releasing" && (
        <div className="flex flex-col items-center gap-6 py-8">
          <div className="releasing-container relative">
            <p className="releasing-text max-w-md text-center font-serif text-lg text-foreground/80 leading-relaxed">
              {thought}
            </p>
            {/* Particle effect overlay */}
            <div className="particles-overlay" aria-hidden="true">
              {Array.from({ length: 12 }).map((_, i) => (
                <span
                  key={i}
                  className="particle"
                  style={
                    {
                      "--delay": `${i * 0.08}s`,
                      "--x": `${(Math.random() - 0.5) * 120}px`,
                      "--y": `${Math.random() * 80 + 40}px`,
                      "--rotation": `${Math.random() * 360}deg`,
                    } as React.CSSProperties
                  }
                />
              ))}
            </div>
          </div>

          {/* Trash can visual */}
          <div className="trash-can-visual">
            <Trash2 className="h-12 w-12 text-muted-foreground/40" />
          </div>
        </div>
      )}

      {phase === "affirmed" && (
        <div className="flex flex-col items-center gap-4 py-12 animate-fade-in-up">
          <div className="flex h-16 w-16 items-center justify-center rounded-full bg-primary/10">
            <svg
              className="h-8 w-8 text-primary"
              fill="none"
              viewBox="0 0 24 24"
              stroke="currentColor"
              strokeWidth={2}
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                d="M5 13l4 4L19 7"
              />
            </svg>
          </div>
          <p className="max-w-sm text-center font-serif text-xl text-foreground leading-relaxed">
            {affirmation}
          </p>
        </div>
      )}
    </div>
  )
}
